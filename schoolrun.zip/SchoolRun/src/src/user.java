package src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

class User {
	private String name;
	private String pwd;
	private int login_check = 0;
	String url = "jdbc:mysql://localhost:3306/schoolrun?serverTimezone = UTC";
	String driver = "com.mysql.cj.jdbc.Driver";
	String id = "root";
	String pw = "mirim";
	String sql;
	Connection conn;

	public int login(String name, String pwd) {
		this.name = name;
		this.pwd = pwd;
		
		try {
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("DB Connect OK");
			
			Statement stmt = conn.createStatement();
			sql = "select * from user where name='"+ name +"';";
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs!=null) {
				while(rs.next()) {
					if(pwd.equals(rs.getString("pw"))) {
						System.out.println("�α��� ����!");
						this.login_check = 1;
					}
				}
			}
		} catch (Exception e) {
			e.toString();
		}
		return this.login_check;
	}
	
	
	public void join(String name, String pwd) {
		this.name = name;
		this.pwd = pwd;
		try {
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("DB Connect OK");
			Statement stmt = conn.createStatement();
			sql = "insert into user(name, pw) value('" + name + "', '" + pwd +"');";
			stmt.executeUpdate(sql);
			System.out.println("���Լ���!");
		} catch (Exception e) {
			e.toString();
		}
	}
}