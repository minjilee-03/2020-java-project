package src;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewAccount {

	private JFrame frame;
	private JTextField textField;
	private JButton btnNewButton;
	private JTextField textField_1;
	private JTextField textField_2;
	private JButton button;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewAccount window = new NewAccount();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NewAccount() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 717, 738);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("�޸յձ�������", Font.PLAIN, 21));
		textField.setBounds(112, 268, 352, 59);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("..\\image\\double_check.jpg"));
		btnNewButton.setBounds(496, 268, 124, 59);
		frame.getContentPane().add(btnNewButton);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("�޸յձ�������", Font.PLAIN, 21));
		textField_1.setColumns(10);
		textField_1.setBounds(112, 360, 352, 59);
		frame.getContentPane().add(textField_1);
		textField_1.setOpaque(true);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("�޸յձ�������", Font.PLAIN, 21));
		textField_2.setColumns(10);
		textField_2.setBounds(112, 448, 352, 59);
		frame.getContentPane().add(textField_2);
		textField_2.setOpaque(true);
		
		button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id = textField.getText();
				String pw = textField_1.getText();
				
				User u1 = new User();
				u1.join(id, pw);
				
				frame.setVisible(false);
				Main_login l1 = new Main_login();
				l1.main(null);
				
			}
		});
		button.setIcon(new ImageIcon("..\\image\\create_account_cp.jpg"));
		button.setBounds(257, 558, 223, 59);
		frame.getContentPane().add(button);
		
		label = new JLabel("\uB2C9\uB124\uC784 ");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("HY�ٴ�M", Font.BOLD, 20));
		label.setBounds(112, 245, 82, 21);
		frame.getContentPane().add(label);
		
		label_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("HY�ٴ�M", Font.BOLD, 20));
		label.setFont(new Font("HY�ٴ�M", Font.BOLD, 20));
		label_1.setBounds(112, 339, 124, 21);
		frame.getContentPane().add(label_1);
		
		label_2 = new JLabel("\uBE44\uBC00\uBC88\uD638 \uC7AC\uD655\uC778");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("HY�ٴ�M", Font.BOLD, 20));
		label.setFont(new Font("HY�ٴ�M", Font.BOLD, 20));
		label_2.setBounds(112, 426, 230, 21);
		frame.getContentPane().add(label_2);
		
		JCheckBox checkBox = new JCheckBox("\uD68C\uC6D0\uAC00\uC785\uC5D0 \uB3D9\uC758\uD569\uB2C8\uB2E4.");
		checkBox.setFont(new Font("HY�ٴ�M", Font.BOLD, 18));
		checkBox.setBounds(112, 518, 352, 29);
		frame.getContentPane().add(checkBox);
		
		btnNewButton_1 = new JButton("");
		btnNewButton_1.setIcon(new ImageIcon("..\\image\\close.jpg"));
		btnNewButton_1.setBounds(652, 0, 43, 43);
		frame.getContentPane().add(btnNewButton_1);
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			}
		});
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("..\\image\\new_acount.jpg"));
		lblNewLabel.setBounds(0, 0, 695, 682);
		frame.getContentPane().add(lblNewLabel);
	}
}
