/*
 * package src; import java.awt.BorderLayout; import java.awt.EventQueue; import
 * java.awt.Graphics; import java.awt.Image; import java.awt.event.KeyEvent;
 * import java.sql.Timestamp; import java.time.LocalDateTime;
 * 
 * import javax.swing.ImageIcon; import javax.swing.JFrame; import
 * javax.swing.JPanel;
 * 
 * public class Jump {
 * 
 * private JFrame frame;
 * 
 * int field = 250;
 * 
 * ImageIcon ic = new ImageIcon("..\\image\\grade1.gif"); Image img =
 * ic.getImage();
 * 
 * int imgY = 5;
 * 
 * boolean fall = false; boolean jump = false;
 * 
 * 
 * static long getTime() { return
 * Timestamp.valueOf(LocalDateTime.now()).getTime(); }
 * 
 * class MyPanel extends JPanel{ public MyPanel() { setFocusable(true); }
 * 
 * @Override protected void paintComponent(Graphics g) {
 * super.paintComponent(g); g.drawImage(img, 100, imgY, this); } } private void
 * intialize() { frame = new JFrame(); frame.setBounds(100, 100, 450, 300);
 * frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 * 
 * JPanel panel = new MyPanel(); frame.getContentPane().add(panel,
 * BorderLayout.CENTER); panel.setLayout(null); } }
 * 
 * 
 * class MyPanel extends JPanel{ public MyPanel() { setFocusable(true);
 * 
 * new Thread(new Runnable() {
 * 
 * @Override public void run() { while(true) { int foot = imgY +
 * img.getHight(null); if(jump == fales && foot < filed && fall == false) { fall
 * = true; System.out.println("���Ͻ���"); long t1 = getTime(); long t2; int set =
 * 1; while(foot<filed) { t2 = getTime()-t1; int jumpY = set + (int) ((t2)/40);
 * imgY = imgY + jumpY; foot = imgY + img.getHieght(null); repaint(); try {
 * Thread.sleep(10); }catch(InterruptedException e) { e.printStackTrace(); } }
 * fall = false;
 * 
 * } try { Thread.sleep(10);
 * 
 * }catch(InterruptedException e) { e.printStackTrace(); } } } }).start();
 * 
 * addKeyListener(new KeyAdapter() {
 * 
 * @Override public void keyPressed(KeyEvent e) { if(e.getKeyCode() ==
 * KeyEvent.VK_SPACE && jump == false) { new Thread(new Runnable() {
 * 
 * @override public void run() { int foot = imgY + img.getHight(null); if(fall
 * == false) { jump = true; System.out.println("��������"); long t1 = getTime();
 * long t2; int set = 8; int jumpY = 8; while(jumpY > 0) { t2 = getTime() - t1;
 * jumpY = set - (int)((t2)/40); imgY = imgY - jumpY; foot = imgY +
 * img.getHeight(null); repaint(); try { Thread.sleep(10);
 * }catch(InterruptedException e) { e.printStackTrace(); } } jump = false; } }
 * }).start(); } } }); }
 * 
 * 
 */