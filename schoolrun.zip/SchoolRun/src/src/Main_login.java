package src;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JScrollBar;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.ImageIcon;

public class Main_login extends JFrame {

	private JPanel contentPane;
	private JTextField id;
	private JLabel result;
	private JPasswordField pwd;
	private JButton button;
	private JButton button_1;
	private JLabel lblNewLabel_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_login frame = new Main_login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main_login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //â ����
		setBounds(100, 100, 1500, 850); //
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514(*\uBAA8\uB4E0 \uC544\uC774\uB514\uB294 \uB2C9\uB124\uC784)");
		lblNewLabel.setBounds(530, 370, 316, 46);
		contentPane.add(lblNewLabel);
		
		id = new JTextField(); //���̵� �ؽ�Ʈ�ʵ�
		id.setFont(new Font("�޸յձ�������", Font.PLAIN, 30));
		id.setBounds(530, 411, 286, 57);
		contentPane.add(id);
		id.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("��й�ȣ"); //��й�ȣ �ؽ�Ʈ�ʵ�
		lblNewLabel_1.setBounds(530, 468, 147, 21);
		contentPane.add(lblNewLabel_1);
		
		JButton login = new JButton(""); //�α��� ��ư
		login.setIcon(new ImageIcon("..\\image\\login.jpg"));
	
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String strId=id.getText();
				String strPw=String.valueOf(pwd.getPassword());
				User u1 = new User(); //�α��� Ŭ����
				int check = u1.login(strId, strPw);
				
				if(check==1) {
					setVisible(false);
					Main_start m1 = new Main_start(); 
					m1.main(null);
				} else {
					result.setText("���̵� �Ǵ� ��� ��ȣ�� ��ġ���� �ʽ��ϴ�.");
					result.setForeground(Color.white);
				}
			}
		});
		login.setBounds(831, 411, 136, 136);
		contentPane.add(login);
		
		result = new JLabel(""); //�α��ΰ��
		result.setFont(new Font("���� ����", Font.BOLD, 14));
		result.setBackground(Color.DARK_GRAY);
		result.setBounds(530, 611, 361, 46);
		contentPane.add(result);
		
		result.setOpaque(true);//������
		
		pwd = new JPasswordField(); //��й�ȣ
		pwd.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 30));
		pwd.setBounds(530, 490, 286, 57);
		contentPane.add(pwd);
		
		button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				NewAccount a1 = new NewAccount(); 
				a1.main(null);
			}
		});
		button.setIcon(new ImageIcon("..\\image\\new_count.jpg"));
		button.setBounds(530, 562, 136, 34);
		contentPane.add(button);
		
		button_1 = new JButton(""); //�Խ�Ʈ���
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false); //�� â�� ������ �ʰ��ϰ�
				Main_start m1 = new Main_start(); 
				m1.main(null);
			}
		});
		button_1.setIcon(new ImageIcon("..\\image\\guest_bt.jpg"));
		button_1.setBounds(683, 562, 136, 34);
		contentPane.add(button_1);
		
		lblNewLabel_2 = new JLabel(""); //���
		lblNewLabel_2.setIcon(new ImageIcon("..\\image\\start_background.jpg"));
		lblNewLabel_2.setBounds(0, 0, 1478, 794);
		contentPane.add(lblNewLabel_2);
	}
}